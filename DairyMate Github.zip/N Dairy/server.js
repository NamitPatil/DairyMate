const express = require("express");
const mysql = require("mysql2");
const path = require("path");
const session = require('express-session');
const { name } = require("ejs");

const app = express();
const port = 3000;

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));
app.use(session({
    secret: 'dairymate-secret-key',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 24 * 60 * 60 * 1000 }
}));

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

const db = mysql.createConnection({
    host: "localhost",
    user: "root", 
    password: "namit1008", 
    database: "DairyMate",
    timezone: '+05:30'
});

db.connect((err) => {
    if (err) {
        console.error("Database connection failed: " + err.message);
    } else {
        console.log("✅ Connected to MySQL database");
    }
});


app.get("/", (req, res) => res.render("home"));
app.get("/home", (req, res) => res.render("home"));
app.get("/logout", (req, res) => {
    req.session.destroy();
    res.redirect("/");
});
app.get("/login", (req, res) => res.render("login"));
app.get("/signup", (req, res) => res.render("signup"));
app.get("/admin", (req, res) => {
    if (!req.session.isAdmin) {
        return res.redirect("/login");
    }
    res.render("admin");
});
app.get("/user", (req, res) => {
    if (!req.session.userId || !req.session.user) {
        return res.redirect("/login");
    }
    res.render("user", { user: req.session.user });
});

app.post("/login", (req, res) => {
    const { email, password } = req.body;

    if (email === "admin123@gmail.com" && password === "admin123") {
        req.session.isAdmin = true;
        return res.redirect("/admin");
    }

    const sql = "SELECT * FROM users WHERE email = ? AND password = ?";
    db.query(sql, [email, password], (err, results) => {
        if (err) {
            return res.status(500).send("Error during login.");
        }
        
        if (results.length > 0) {
            const user = results[0];
            req.session.userId = user.user_id;
            req.session.user = {
                id: user.user_id,
                name: user.full_name,
                email: user.email
            };
            res.redirect("/user");
        } else {
            res.send("Invalid email or password!");
        }
    });
});

app.post("/signup", (req, res) => {
   
    const { 
        name,           
        contact,       
        email,        
        password,    
        animal_type    
    } = req.body;

    
    const formattedAnimalType = animal_type.charAt(0).toUpperCase() + animal_type.slice(1);

   
    const sql = `
        INSERT INTO users 
        (full_name, contact_number, email, password, animal_type) 
        VALUES (?, ?, ?, ?, ?)
    `;

    
    db.query(
        sql, 
        [name, contact, email, password, formattedAnimalType],
        (err, result) => {
            if (err) {
                console.error("Error during signup:", err);
                
                return res.redirect('/signup?error=true');
            }
            
            
            res.redirect('/login');
        }
    );
});


app.get("/api/all-users-data", (req, res) => {
    const today = new Date().toISOString().split('T')[0];
    const sql = `
    SELECT 
        u.user_id AS id,
        u.full_name AS name,
        u.contact_number AS phone,
        u.animal_type,
        COALESCE(SUM(m.milk_quantity), 0) AS today_milk
    FROM users u
    LEFT JOIN milk_collection m 
        ON u.user_id = m.user_id AND DATE(m.record_date) = CURDATE()
    GROUP BY u.user_id, u.full_name, u.contact_number, u.animal_type
`;
    db.query(sql, [today], (err, results) => {
        if (err) {
            console.error("Error fetching all users data:", err);
            return res.status(500).json([]);
        }
        res.json(results);
    });
});

app.get('/api/dashboard-stats', (req, res) => {
    const today = new Date().toISOString().split('T')[0];
    
    const queries = {
        totalUsers: 'SELECT COUNT(*) as count FROM users',
        todayStats: `
            SELECT 
                COALESCE(SUM(milk_quantity), 0) as total_milk,
                COALESCE(AVG(fat_percentage), 0) as avg_fat,
                COUNT(DISTINCT user_id) as active_users,
                COALESCE(SUM(total_amount), 0) as total_amount
            FROM milk_collection 
            WHERE DATE(record_date) = ?`
    };

    db.query(queries.totalUsers, (err, userResults) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        db.query(queries.todayStats, [today], (err, statsResults) => {
            if (err) {
                return res.status(500).json({ error: err.message });
            }

            res.json({
                totalUsers: userResults[0].count,
                todayCollection: parseFloat(statsResults[0].total_milk).toFixed(2),
                averageFat: parseFloat(statsResults[0].avg_fat).toFixed(1),
                activeUsers: statsResults[0].active_users,
                todayAmount: parseFloat(statsResults[0].total_amount).toFixed(2)
            });
        });
    });
});

app.post("/api/add-user", (req, res) => {
    const { name, phone, email, password, bankAccount, animalType } = req.body;
    const sql = 'INSERT INTO users (full_name, contact_number, email, password, bank_account_number, animal_type) VALUES (?, ?, ?, ?, ?, ?)';
    db.query(sql, [name, phone, email, password, bankAccount, animalType], (err, result) => {
        if (err) {
            res.json({ success: false, error: err.message });
            return;
        }
        res.json({ success: true, id: result.insertId });
    });
});

app.delete("/api/delete-user/:id", (req, res) => {
    const userId = req.params.id;
    
    db.query("DELETE FROM milk_collection WHERE user_id = ?", [userId], (err) => {
        if (err) {
            return res.status(500).json({ success: false, message: "Error deleting user's milk records" });
        }
        
        db.query("DELETE FROM users WHERE user_id = ?", [userId], (err) => {
            if (err) {
                return res.status(500).json({ success: false, message: "Error deleting user" });
            }
            res.json({ success: true });
        });
    });
});

app.get("/api/get-milk-rate/:fat", (req, res) => {
    const fatPercentage = parseFloat(req.params.fat).toFixed(1);
    const sql = "SELECT rate FROM milk_rates WHERE fat_percentage = ?";
    
    db.query(sql, [fatPercentage], (err, results) => {
        if (err) {
            return res.json({ success: false, error: err });
        }
        if (results.length > 0) {
            const rate = parseFloat(results[0].rate);
            res.json({ success: true, rate: rate });
        } else {
            res.json({ success: false, message: 'Rate not found for given fat percentage' });
        }
    });
});

app.get("/api/milk-rates", (req, res) => {
    const sql = "SELECT fat_percentage, rate FROM milk_rates ORDER BY fat_percentage";
    db.query(sql, (err, results) => {
        if (err) {
            return res.json({ success: false, error: err });
        }
        res.json(results);
    });
});

app.post("/api/update-milk-rates", (req, res) => {
    const { rates, adminPassword } = req.body;
    
    if (adminPassword !== 'admin123') {
        return res.json({ success: false, message: 'Invalid admin password' });
    }

    db.query("DELETE FROM milk_rates", (err) => {
        if (err) {
            return res.json({ success: false, error: err });
        }

        const sql = "INSERT INTO milk_rates (fat_percentage, rate) VALUES ?";
        const values = rates.map(rate => [parseFloat(rate.fat).toFixed(1), parseFloat(rate.price)]);

        db.query(sql, [values], (err) => {
            if (err) {
                return res.json({ success: false, error: err });
            }
            res.json({ success: true });
        });
    });
});

app.post("/api/add-milk-entry", (req, res) => {
    const { userId, date, quantity, fatPercentage, shift } = req.body;
    
    const sql1 = "SELECT rate FROM milk_rates WHERE fat_percentage = ?";
    db.query(sql1, [parseFloat(fatPercentage).toFixed(1)], (err, results) => {
        if (err) {
            return res.status(500).json({ success: false, error: err.message });
        }

        if (results.length === 0) {
            return res.json({ success: false, message: "Rate not found for given fat percentage" });
        }

        const rate = parseFloat(results[0].rate);
        const qty = parseFloat(quantity);
        const totalAmount = qty * rate;

        const sql2 = `
            INSERT INTO milk_collection 
            (user_id, record_date, milk_quantity, fat_percentage, price_per_litre, total_amount, shift) 
            VALUES (?, ?, ?, ?, ?, ?, ?)
        `;

        db.query(sql2, [
            userId,
            date,
            qty,
            parseFloat(fatPercentage).toFixed(1),
            rate,
            totalAmount,
            shift
        ], (err) => {
            if (err) {
                return res.status(500).json({ success: false, error: err.message });
            }
            res.json({ success: true });
        });
    });
});

app.get("/api/reports", (req, res) => {
    const { fromDate, toDate, userId } = req.query;
    let sql = `
        SELECT 
            DATE_FORMAT(m.record_date, '%Y-%m-%d') as record_date,
            u.full_name as name,
            m.milk_quantity,
            m.fat_percentage,
            m.price_per_litre,
            m.shift,
            m.total_amount,
            CASE 
                WHEN m.fat_percentage >= 6.0 THEN 'Buffalo'
                ELSE 'Cow'
            END as milk_type
        FROM milk_collection m 
        JOIN users u ON m.user_id = u.user_id 
        WHERE DATE(m.record_date) >= DATE(?) 
        AND DATE(m.record_date) <= DATE(?)
    `;
    
    const params = [fromDate, toDate];
    
    if (userId && userId !== '') {
        sql += ' AND m.user_id = ?';
        params.push(userId);
    }
    
    sql += ' ORDER BY m.record_date DESC, FIELD(m.shift, "morning", "evening")';

    db.query(sql, params, (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        const formattedResults = results.map(row => ({
            record_date: row.record_date,
            name: row.name,
            session: row.shift,
            milk_type: row.milk_type + ' Milk',
            milk_quantity: parseFloat(row.milk_quantity).toFixed(2),
            fat_percentage: parseFloat(row.fat_percentage).toFixed(1),
            price_per_litre: parseFloat(row.price_per_litre).toFixed(2),
            total_amount: parseFloat(row.total_amount).toFixed(2)
        }));
        
        res.json(formattedResults);
    });
});

app.get("/api/user-dashboard/:userId", (req, res) => {
    const userId = req.params.userId;
    const today = new Date().toISOString().split('T')[0];
    
    const sql = `
        SELECT 
            COALESCE(SUM(milk_quantity), 0) as today_milk,
            COALESCE(AVG(fat_percentage), 0) as avg_fat,
            COALESCE(SUM(total_amount), 0) as today_amount
        FROM milk_collection 
        WHERE user_id = ? AND DATE(record_date) = ?
        GROUP BY user_id
    `;
    
    db.query(sql, [userId, today], (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        
        const data = results.length > 0 ? results[0] : {
            today_milk: 0,
            avg_fat: 0,
            today_amount: 0
        };
        
        res.json({
            todayMilk: parseFloat(data.today_milk).toFixed(2),
            avgFat: parseFloat(data.avg_fat).toFixed(1),
            todayAmount: parseFloat(data.today_amount).toFixed(2)
        });
    });
});

app.get("/api/user-reports/:userId", (req, res) => {
    const userId = req.params.userId;
    const { fromDate, toDate } = req.query;
    
    const sql = `
        SELECT 
            DATE_FORMAT(record_date, '%Y-%m-%d') as record_date,
            milk_quantity,
            fat_percentage,
            price_per_litre,
            shift,
            total_amount,
            CASE 
                WHEN fat_percentage >= 6.0 THEN 'Buffalo'
                ELSE 'Cow'
            END as milk_type
        FROM milk_collection 
        WHERE user_id = ? 
        AND DATE(record_date) >= DATE(?)
        AND DATE(record_date) <= DATE(?)
        ORDER BY record_date DESC, FIELD(shift, "morning", "evening")
    `;
    
    db.query(sql, [userId, fromDate, toDate], (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        
        const formattedResults = results.map(row => ({
            record_date: row.record_date,
            session: row.shift,
            milk_type: row.milk_type + ' Milk',
            milk_quantity: parseFloat(row.milk_quantity).toFixed(2),
            fat_percentage: parseFloat(row.fat_percentage).toFixed(1),
            price_per_litre: parseFloat(row.price_per_litre).toFixed(2),
            total_amount: parseFloat(row.total_amount).toFixed(2)
        }));
        
        res.json(formattedResults);
    });
});

app.get("/api/user-profile/:userId", (req, res) => {
    const userId = req.params.userId;
    
    const sql = "SELECT * FROM users WHERE user_id = ?";
    db.query(sql, [userId], (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        
        if (results.length === 0) {
            return res.status(404).json({ error: "User not found" });
        }
        
        const user = results[0];
        res.json({
            user_id: user.user_id,
            full_name: user.full_name,
            email: user.email,
            contact_number: user.contact_number,
            bank_account_number: user.bank_account_number,
            animal_type: user.animal_type
        });
    });
});

app.post("/api/update-profile", (req, res) => {
    const { userId, fullName, email, phone, bankAccount, animalType, currentPassword } = req.body;
    
    const verifySQL = "SELECT * FROM users WHERE user_id = ? AND password = ?";
    db.query(verifySQL, [userId, currentPassword], (err, results) => {
        if (err) {
            return res.status(500).json({ success: false, message: "Error verifying password" });
        }
        
        if (results.length === 0) {
            return res.json({ success: false, message: "Invalid password" });
        }
        
        const updateSQL = `
            UPDATE users 
            SET full_name = ?, 
                email = ?, 
                contact_number = ?, 
                bank_account_number = ?,
                animal_type = ?
            WHERE user_id = ?
        `;
        
        db.query(updateSQL, [fullName, email, phone, bankAccount, animalType, userId], (err) => {
            if (err) {
                return res.status(500).json({ success: false, message: "Error updating profile" });
            }
            res.json({ success: true, message: "Profile updated successfully" });
        });
    });
});

app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});