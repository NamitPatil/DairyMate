function validated() {
    let name = document.forms["form"]["name"].value;
    let email = document.forms["form"]["email"].value;
    let contact = document.forms["form"]["contact"].value;
    let password = document.forms["form"]["password"].value;
    let confirmPassword = document.forms["form"]["confirm_password"].value;

    // Email Validation
    let emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
    if (!email.match(emailPattern)) {
        document.getElementById("email_error").style.display = "block";
        return false;
    } else {
        document.getElementById("email_error").style.display = "none";
    }

    // Contact Number Validation (Only Numbers, 10 Digits)
    let phonePattern = /^[0-9]{10}$/;
    if (!contact.match(phonePattern)) {
        alert("Please enter a valid 10-digit contact number.");
        return false;
    }

    // Password Match Validation
    if (password !== confirmPassword) {
        document.getElementById("pass_error").style.display = "block";
        return false;
    } else {
        document.getElementById("pass_error").style.display = "none";
    }

    return true; // Submit the form if validation passes
}
