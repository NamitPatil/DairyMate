function loadContent(page) {
    let contentSection = document.getElementById("content-section");

    if (!contentSection) {
        console.error("Content section not found!");
        return;
    }

    // Remove existing content
    contentSection.innerHTML = "";

    // Dynamically load the selected page content
    if (page === "milk-tracker") {
        contentSection.innerHTML = `
            <div class="container mt-4">
                <h2 class="text-center">Milk Data Tracker</h2>
                
                <label for="datePicker" class="form-label">Select a Date:</label>
                <input type="date" id="datePicker" class="form-control mb-3">
                
                <table class="table table-striped table-hover text-center">
                    <thead class="table-primary">
                        <tr>
                            <th>Date</th>
                            <th>Milk Quantity (L)</th>
                            <th>Fat (%)</th>
                            <th>Rate (₹/L)</th>
                        </tr>
                    </thead>
                    <tbody id="dataTable">
                        <tr><td colspan="4">Select a date to view data</td></tr>
                    </tbody>
                </table>
                
                <h3 class="mt-4">Weekly & Monthly Record</h3>
                <button class="btn btn-primary" onclick="displayRecords('weekly')">Show Weekly Record</button>
                <button class="btn btn-success" onclick="displayRecords('monthly')">Show Monthly Record</button>
                
                <table class="table table-bordered mt-3 text-center">
                    <thead class="table-secondary">
                        <tr>
                            <th>Date</th>
                            <th>Milk Quantity (L)</th>
                            <th>Fat (%)</th>
                            <th>Rate (₹/L)</th>
                        </tr>
                    </thead>
                    <tbody id="recordTable">
                        <tr><td colspan="4">Click a button to display records</td></tr>
                    </tbody>
                </table>
            </div>
        `;
    } 
    else if (page === "view-bill") {
        contentSection.innerHTML = `
            <div class="container mt-4">
                <h2 class="text-center">Previous Weekly Bills</h2>
                <input type="date" id="calendar" class="form-control mt-3">
                
                <div id="billDetails" class="mt-3 text-center"></div>

                <table class="table table-bordered mt-3 text-center">
                    <thead class="table-secondary">
                        <tr>
                            <th>Week</th>
                            <th>Total Milk (L)</th>
                            <th>Average Fat (%)</th>
                            <th>Total Amount (₹)</th>
                        </tr>
                    </thead>
                    <tbody id="billsTable">
                        <tr><td colspan="4" class="text-danger">No previous bills found</td></tr>
                    </tbody>
                </table>
            </div>
        `;
    }
    else if (page === "notifications") {
        contentSection.innerHTML = `
            <div class="text-center mt-4">
                <h2>Notifications</h2>
                <p>Check the latest updates and alerts.</p>
                <ul class="list-group">
                    <li class="list-group-item">📢 New milk price update available.</li>
                    <li class="list-group-item">🔔 Payment reminder for pending bills.</li>
                    <li class="list-group-item">📅 Next milk collection scheduled for tomorrow.</li>
                </ul>
            </div>
        `;
    }
}

/* Logout Function */
function logout() {
    localStorage.removeItem("isLoggedIn");
    window.location.href = "index.html";
}
