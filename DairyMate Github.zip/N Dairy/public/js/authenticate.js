document.addEventListener("DOMContentLoaded", function () {
    const isLoggedIn = localStorage.getItem("isLoggedIn");

    if (isLoggedIn) {
        document.getElementById("navbarNav").innerHTML = `
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="#">Milk Tracker</a></li>
                <li class="nav-item"><a class="nav-link" href="#">View Bill</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Notification</a></li>

                <!-- Profile Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="profileDropdown" role="button" data-bs-toggle="dropdown">
                        <img src="images/profile-icon.png" alt="Profile" class="profile-icon">
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="#">Profile</a></li>
                        <li><a class="dropdown-item" href="#">Settings</a></li>
                        <li><a class="dropdown-item" href="index.html" onclick="logout()">Logout</a></li>
                    </ul>
                </li>
            </ul>
        `;
    }
});

function logout() {
    localStorage.removeItem("isLoggedIn");
    window.location.href = "index.html"; // Redirect to homepage
}
