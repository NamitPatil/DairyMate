const datePicker = document.getElementById("datePicker");
const dataTable = document.getElementById("dataTable");
const recordTable = document.getElementById("recordTable");

// Fetch by Date
datePicker.addEventListener("change", function() {
    const selectedDate = this.value;
    fetch(`/api/milk-data?type=date&date=${selectedDate}`)
        .then(res => res.json())
        .then(data => {
            if (data.length > 0) {
                const { record_date, milk_quantity, fat_percentage, price_per_litre } = data[0];
                dataTable.innerHTML = `
                    <tr>
                        <td>${record_date}</td>
                        <td>${milk_quantity} L</td>
                        <td>${fat_percentage} %</td>
                        <td>₹${price_per_litre}/L</td>
                    </tr>
                `;
            } else {
                dataTable.innerHTML = `<tr><td colspan="4" class="text-danger">No data available</td></tr>`;
            }
        });
});

function displayRecords(type) {
    recordTable.innerHTML = "";
    fetch(`/api/milk-data?type=${type}`)
        .then(res => res.json())
        .then(data => {
            if (data.length > 0) {
                data.forEach(row => {
                    const { record_date, milk_quantity, fat_percentage, price_per_litre } = row;
                    recordTable.innerHTML += `
                        <tr>
                            <td>${record_date}</td>
                            <td>${milk_quantity} L</td>
                            <td>${fat_percentage} %</td>
                            <td>₹${price_per_litre}/L</td>
                        </tr>
                    `;
                });
            } else {
                recordTable.innerHTML = `<tr><td colspan="4" class="text-danger">No records found</td></tr>`;
            }
        });
}
