const previousBillsTable = document.getElementById("billsTable");
const calendar = document.getElementById("calendar");
const billDetails = document.getElementById("billDetails");

// Load previous bills on page load
displayPreviousBills();
highlightBillDates();

// Function to display all previous weekly bills
function displayPreviousBills() {
    previousBillsTable.innerHTML = "";
    let previousBills = JSON.parse(localStorage.getItem("weeklyBills")) || [];
    
    if (previousBills.length === 0) {
        previousBillsTable.innerHTML = `<tr><td colspan="4" class="text-danger">No previous bills found</td></tr>`;
        return;
    }

    previousBills.forEach(bill => {
        let averageFat = calculateAverageFat(bill.week);
        previousBillsTable.innerHTML += `
            <tr>
                <td>${bill.week}</td>
                <td>${bill.totalMilk} L</td>
                <td>${averageFat.toFixed(2)} %</td>
                <td>₹${bill.totalAmount}</td>
            </tr>
        `;
    });
}

// Function to calculate average fat content for a given week
function calculateAverageFat(weekRange) {
    let [startDate, endDate] = weekRange.split(" to ");
    let totalFat = 0, count = 0;
    
    let currentDate = new Date(startDate);
    let lastDate = new Date(endDate);
    
    while (currentDate <= lastDate) {
        let dateString = currentDate.toISOString().split("T")[0];
        if (milkData[dateString]) {
            totalFat += milkData[dateString].fat;
            count++;
        }
        currentDate.setDate(currentDate.getDate() + 1);
    }
    
    return count > 0 ? totalFat / count : 0;
}

// Function to highlight days when bills were received
function highlightBillDates() {
    let billDates = JSON.parse(localStorage.getItem("billDates")) || [];
    billDates.forEach(date => {
        let dateElement = document.querySelector(`[data-date='${date}']`);
        if (dateElement) {
            dateElement.style.backgroundColor = "#ffcccc"; // Highlight bill days
            dateElement.addEventListener("click", () => showBillDetails(date));
        }
    });
}

// Function to show bill details when a date is clicked
function showBillDetails(date) {
    let previousBills = JSON.parse(localStorage.getItem("weeklyBills")) || [];
    let bill = previousBills.find(b => b.week.includes(date));
    
    if (bill) {
        billDetails.innerHTML = `
            <h4>Bill Details for ${date}</h4>
            <p><strong>Total Milk:</strong> ${bill.totalMilk} L</p>
            <p><strong>Average Fat:</strong> ${calculateAverageFat(bill.week).toFixed(2)} %</p>
            <p><strong>Total Amount:</strong> ₹${bill.totalAmount}</p>
        `;
    } else {
        billDetails.innerHTML = `<p class='text-danger'>No bill found for this date</p>`;
    }
}
